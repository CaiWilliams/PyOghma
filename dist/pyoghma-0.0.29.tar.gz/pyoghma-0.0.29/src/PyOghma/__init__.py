from .OghmaNano import OghmaNano
from .OghmaResults import Results

